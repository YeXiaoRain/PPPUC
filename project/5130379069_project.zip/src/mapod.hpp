#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <vector>
#include <string>
#include <cstdint>
#include <cstring>

#ifdef DEBUG
#include <iostream>
#include <signal.h>
#define error(msg)                                                      \
  do {                                                                  \
    std::cerr << __FILE__ ":" << __LINE__                               \
              << ":"<< msg << std::endl;                                \
    raise(SIGINT);                                                      \
  } while (0)
#else
#include <sstream>
#define  error(msg)                             \
  do {                                          \
    std::ostringstream oss;                     \
    oss << msg;                                 \
    _msg = oss.str();                           \
  } while (0)
#endif

#define assert(pred)                            \
  do {                                          \
    if (!(pred))                                \
    error("assert(" #pred ") not met");         \
  } while (0)

/*
  allocating of file, mapping file to memory, etc
  currently it's append-only
*/
class MManager {
public:
  MManager(const int fd, const off_t blksize = 4 * 1024 * 1024);
  ~MManager();
  void *operator[](const off_t off);
  off_t alloc(const off_t size, const off_t align = 4);
  void dealloc(const off_t off);
  off_t realloc(const off_t off, const off_t size, const off_t align = 4);
  off_t size();

private:
  std::vector<void *> _addr;
  size_t _size;//promised size in last block
  size_t _blksize;
  int _fd;//corresponding fd
  std::string _msg; //error message
};

//short for Dump-Load-Destroy
template <typename Type>
struct DLD {
  typedef  off_t Dump(const Type &, MManager &);
  typedef Type Load(const off_t, MManager &);
  typedef void Destroy(const off_t, MManager &);
  Dump *dump;
  Load *load;
  Destroy *destroy;
  static Dump defaultDump;
  static Load defaultLoad;
  static Destroy defaultDestroy;
  static DLD defaultDLD;
};

template <typename Type>
DLD<Type> DLD<Type>::defaultDLD{DLD<Type>::defaultDump, DLD<Type>::defaultLoad, DLD<Type>::defaultDestroy};

template <typename Type>
off_t DLD<Type>::defaultDump(const Type &t, MManager &mm)
{
  if (sizeof(Type) > sizeof(off_t)) {
    //if it's too large, allocate for extra memory
    off_t off = mm.alloc(sizeof(t), sizeof(off_t));
    memcpy(mm[off], &t, sizeof(t));
    return off;
  } else {
    //if it's not too big, make it inline
    return *(off_t *)&t;
  }
}

template <typename Type>
Type DLD<Type>::defaultLoad(const off_t off, MManager &mm)
{
  if (sizeof(Type) > sizeof(off_t)) {
    return *(Type *)(mm[off]);
  } else {
    return *(Type *)(&off);
  }
}

template <typename Type>
void DLD<Type>::defaultDestroy(const off_t off, MManager &mm)
{
  if (sizeof(Type) > sizeof(off_t))
    //nothing has to be done
    ;
  else {
    mm.dealloc(off);
  }
}


template <typename Key=off_t, typename T=off_t>
class Mapod {
public:
  typedef bool KeyCompare(const Key &key0, const Key &key1);
  static bool compare(const Key &key0, const Key &key1)
  {
    return key0 < key1;
  }

  /*
    blksize is the size of smallest unit in underlying device that our
    database lying on. It's 512 on hard-drives.
    k is the branch-factor, every node in our b+ tree will have [k, 2k]
    child nodes.(except the root node, of course). If zero is given, k
    will be calculated by blksize, such that one node occupy one block.
    key is a series of function to dump, load, and destroy the data of
    every single key.
    t is simlar.
    compare is a function that compare two Key, and return true if the
    first key is strictly ahead of the second one.
    prefix is the prefix of the filename of db files. currently we
    have two file, "prefix.node" to store tree structure,
    "prefix.data" to store user data
   */
  Mapod(const std::string &prefix, const KeyCompare *compare = compare,
        const DLD<Key> &key = DLD<Key>::defaultDLD,
        const DLD<T> &t = DLD<T>::defaultDLD,
        const int k = 0, const off_t blksize = 4 * 1024);
  ~Mapod();

  void set(const Key &key, const T &t);
  T get(const Key &key);
  void del(const Key &key);
 
private:
  //the header in node file
  struct Header {
    //random magic number to recognize node file
    static const uint64_t MAGIC = 0x1a952a8e49c787bb;
    uint64_t magic;
    //currently there's only one field, which points to the root of
    //the b+ tree
    off_t root;
  };

  //the node in b+ tree
  struct Node {
    typedef uint16_t Flags;
    const static Flags FLAG_LEAF = 1;
    Flags flags;
    typedef uint16_t nPair;
    nPair npair;
    
    struct Pair {
      off_t ptr;
      off_t key;
    };
    Pair pairs[];
  };
  
  struct Slot {
    Node *node;
    typename Node::nPair npair;
    //the actual right bound of node
    off_t *rkey;
  };

  KeyCompare *_compare;
  DLD<Key> _key;
  DLD<T> _t;
  int _k;
  off_t _blksize, _nodesize, _datasize;
  Header *_header;
  MManager *_node, *_data;
  int _nodefd, _datafd;
  std::string _msg;

  Slot search(const Key &key);
  Slot isearch(const Key &key);
  off_t split(Node *const node, const typename Node::nPair npair);
  Slot insert(const Key &key, const T &t);
  off_t allocNode(const typename Node::Flags flags,
                  const typename Node::nPair npair);
  void deallocNode(const off_t off);
  Slot remove(const Key &key);
  Slot rsearch(const Key &key);
  void merge(const Slot &slot);
  void resplit(off_t *const key
               ,Node *const node0
               ,Node *const node1
               ,const typename Node::nPair npair);

  void merge(Node *const node
             ,Node *const node0
             ,Node *const node1
             ,const typename Node::nPair npair);
};

MManager::MManager(const int fd, const off_t blksize)
  :_fd(fd)
{
  long pagesize = sysconf(_SC_PAGESIZE);
  _blksize = ((blksize - 1) & ~(pagesize - 1)) + pagesize;

  off_t oldsize;
  if ((oldsize = lseek(fd, 0, SEEK_END)) == -1) {
    error("lseek(): " << strerror(errno));
    return;
  }

  off_t size;
  size = (oldsize / _blksize + 1) * _blksize;
  
  if (ftruncate(_fd, size) == -1) {
    error("ftruncate(): " << strerror(errno));
    return;
  }
  
  int count = size / _blksize;
  
  for (int i = 0; i < count; ++i) {
    void *addr;
    if ((addr = mmap(NULL, _blksize, PROT_READ | PROT_WRITE,
                     MAP_SHARED, _fd, _blksize * i)) == MAP_FAILED) {
      error("mmap(): " << strerror(errno));
      return;
    }
    mlock(addr, _blksize);
    _addr.push_back(addr);
  }
  _size = oldsize % _blksize;
}

MManager::~MManager()
{
  for (auto p = _addr.begin(); p != _addr.end(); ++p)
    munmap(*p, _blksize);
  if (ftruncate(_fd, (_addr.size() - 1) * _blksize + _size) == -1)
    error("ftruncate(): " << strerror(errno));
}

void *MManager::operator[](const off_t offset)
{
  unsigned n = offset / _blksize;
  off_t off = offset % _blksize;
  if (n + 1 < _addr.size())
    return _addr[n] + off;
  else if (n < _addr.size() && off < _size)
    return _addr[n] + off;
  else
    return nullptr;
}

off_t MManager::size()
{
  return (_addr.size() - 1) * _blksize + _size;
}

off_t 
MManager::alloc(const off_t size, const off_t align)
{
  off_t offset = ((_size - 1) & ~(align - 1)) + align;
  if (offset + size > _blksize) {
    if (ftruncate(_fd, (_addr.size() + 1) * _blksize) == -1) {
      error("ftruncate(): " << strerror(errno));
      return -1;
    }
    
    void *addr;
    if ((addr = mmap(NULL, _blksize, PROT_READ | PROT_WRITE,
                     MAP_SHARED, _fd, _blksize * _addr.size())) == MAP_FAILED) {
      error("mmap(): " << strerror(errno));
      return -1;
    }
    mlock(addr, _blksize);
    _addr.push_back(addr);
    _size = 0;
    offset = 0;
  }
  _size = offset + size;
  return (_addr.size() - 1) * _blksize + offset;
}

void
MManager::dealloc(const off_t off)
{
  //currently we does nothing here
  //since our allocator is append-only
}

template<typename Key, typename T>
typename Mapod<Key, T>::Slot Mapod<Key, T>::search(const Key &key)
{
  Node *node = (Node *)(*_node)[_header->root];
  off_t *rkey = nullptr;
  do {
    typename Node::nPair l = 0, r = node->npair;
    while (l < r) {
      typename Node::nPair mid = (l + r) >> 1;
      Key key0(_key.load(node->pairs[mid].key, *_data));
      if (_compare(key0, key))
        l = mid + 1;
      else
        r = mid;
    }
    if (node->flags & Node::FLAG_LEAF)
      return Slot{node, l, rkey};
    if (l < node->npair)
      rkey = &node->pairs[l].key;
    node = (Node *)(*_node)[node->pairs[l].ptr];
  } while (1);
}

template<typename Key, typename T>
typename Mapod<Key, T>::Slot Mapod<Key, T>::isearch(const Key &key)
{
  off_t &node_ = _header->root;
  Node *node = (Node *)(*_node)[node_];
  off_t *rkey = nullptr;
  if (node->npair == 2 * _k - 1) { //the root node is full
    off_t node0_ = node_;
    Node *node0 = node;
    off_t node1_ = split(node0, _k);
    
    node_ = allocNode(0, 1);
    node = (Node *)(*_node)[node_];
    node->npair = 1;
    node->pairs[0].ptr = node0_;
    node->pairs[0].key = node0->pairs[_k - 1].key;
    node->pairs[1].ptr = node1_;
    //    node->pairs[1].key = node0->pairs[_k * 2 - 1].key;
  }
  do {
    typename Node::nPair l = 0, r = node->npair;

    while (l < r) {
      typename Node::nPair mid = (l + r) >> 1;
      Key key0(_key.load(node->pairs[mid].key, *_data));
      if (_compare(key0, key))
        l = mid + 1;
      else
        r = mid;
    }
    if (node->flags & Node::FLAG_LEAF)
      return Slot{node, l, rkey};
    Node *node0 = (Node *)(*_node)[node->pairs[l].ptr];

    if (node0->npair == 2 * _k) { //the node is full
      off_t node1 = split(node0, _k);
      memmove(&node->pairs[l + 1].key, &node->pairs[l].key,
              (node->npair - l) * sizeof(typename Node::Pair));

      node->pairs[l].key = node0->pairs[_k - 1].key;
      node->pairs[l + 1].ptr = node1;
      ++node->npair;

      Key key0(_key.load(node->pairs[l].key, *_data));
      if (_compare(key0, key)) {
        node0 = (Node *)(*_node)[node1];
        ++l;
      }
    }
    if (l < node->npair)
      rkey = &node->pairs[l].key;
    node = node0;
  } while(1);
}

template<typename Key, typename T>
off_t
Mapod<Key, T>::split(Mapod<Key, T>::Node *const node,
      const typename Mapod<Key, T>::Node::nPair npair)
{
  off_t node1 = allocNode(node->flags, node->npair - npair);
  memcpy(&((Node *)(*_node)[node1])->pairs[0].ptr, &node->pairs[npair].ptr,
         (node->npair - npair) * sizeof(typename Node::Pair) + sizeof(off_t));
  node->npair = npair - 1;
  return node1;
}

template<typename Key, typename T>
typename Mapod<Key, T>::Slot
Mapod<Key, T>::insert(const Key &key, const T &t)
{
  Slot slot(isearch(key));
  Node *node = slot.node;
  typename Node::nPair npair = slot.npair;
  off_t *rkey;
  if (npair < node->npair)
    rkey = &node->pairs[npair].key;
  else
    rkey = slot.rkey;
  
  if ((rkey != nullptr) && (!_compare(key, _key.load(*rkey, *_data)))) {
    //the key already exist, overwrite
    node->pairs[npair].ptr = _t.dump(t, *_data);
    return slot;
  }
  
  //insert a new pair
  memmove(&node->pairs[npair + 1].ptr, &node->pairs[npair].ptr,
          (node->npair - npair) * sizeof(typename Node::Pair) + sizeof(off_t));
  
  node->pairs[npair].ptr = _t.dump(t, *_data);
  node->pairs[npair].key = _key.dump(key, *_data);
  ++node->npair;
  return slot;
}

template<typename Key, typename T>
typename Mapod<Key, T>::Slot
Mapod<Key, T>::rsearch(const Key &key)
{
  Node *node = (Node *)(*_node)[_header->root];
  off_t *rkey = nullptr;
  typename Node::nPair l, r;
  do {
    l = 0;
    r = node->npair;
    while (l < r) {
      typename Node::nPair mid = (l + r) >> 1;
      Key key0(_key.load(node->pairs[mid].key, *_data));
      if (_compare(key0, key))
        l = mid + 1;
      else
        r = mid;
    }

    if (node->flags & Node::FLAG_LEAF)
      return Slot{node, l, rkey};

    //here we handle the low-edge overflow
    Node *node0 = (Node *)(*_node)[node->pairs[l].ptr];

    if (node0->npair >= _k)
      //the node is full enough
      goto fin;
    
    Node *node1, *node2;
    if (l - 1 >= 0) {
      // the left sibling exist
      node1 = (Node *)(*_node)[node->pairs[l - 1].ptr];
      if (node1->npair >= _k) {
        resplit(&node->pairs[l - 1].key, node1, node0, (node0->npair + node1->npair) >> 1);
        goto fin;
      }
    } else {
      node1 = nullptr;
    }

    if (l + 1 <= node->npair) {
      node2 = (Node *)(*_node)[node->pairs[l + 1].ptr];
      if (node2->npair >= _k) {
        resplit(&node->pairs[l].key, node0, node2, (node0->npair + node2->npair + 1) >> 1);
        goto fin;
      }
    } else {
      node2 = nullptr;
    }
    
    if (node1 != nullptr) {
      --l;
      merge(node, node1, node0, l);
      node0 = node1;
      goto fin;
    }
    if (node2 != nullptr) {
      merge(node, node0, node2, l);
      goto fin;
    }

    //control should never reach here(in normal case)
    //this happens, when (node=an empty root)
    //&& (node0=an overflow node)
    //if this happens, we delete the root(node), and make his only
    //child(node0) the new root
    {
      off_t &root = _header->root;
      deallocNode(root);
      root = node->pairs[0].ptr;
    }
    
  fin:
    if (l < node->npair)
      rkey = &node->pairs[l].key;
    node = node0;
  } while (1);
}

template<typename Key, typename T>
typename Mapod<Key, T>::Slot
Mapod<Key, T>::remove(const Key &key)
{
  Slot slot(rsearch(key));
  Node *node = slot.node;
  typename Node::nPair npair = slot.npair;
  off_t *rkey;
  if (npair < node->npair)
    rkey = &node->pairs[npair].key;
  else
    rkey = slot.rkey;
  
  if ((rkey != nullptr) && (!_compare(key, _key.load(*rkey, *_data)))) {
    //here we are
    _key.destroy(*rkey, *_data);
    _t.destroy(node->pairs[npair].ptr, *_data);
    if (npair < node->npair)
      memmove(&node->pairs[npair].ptr, &node->pairs[npair + 1].ptr,
              (node->npair - npair) * sizeof(typename Node::Pair) - sizeof(off_t));
    else
      *rkey = node->pairs[npair - 1].key;

    --node->npair;
  }
  return slot;
}

/*
  resplit the border between node0 and node1, such that node0 has
  npair pairs after the resplit. key is a pointer to the key of node0
*/
template<typename Key, typename T>
void Mapod<Key, T>::resplit(off_t *const key
                            ,Mapod<Key, T>::Node *const node0
                            ,Mapod<Key, T>::Node *const node1
                            ,const typename Mapod<Key, T>::Node::nPair npair)
{
  if (npair < node0->npair) {
    // so we want to move some pairs from the
    // former(in the tail) to the later, which is painful
    memmove(&node1->pairs[node0->npair - npair].ptr,
            &node1->pairs[0].ptr,
            node1->npair * sizeof(typename Node::Pair) + sizeof(off_t));
    node1->pairs[node0->npair - npair - 1].key = *key;
    memcpy(&node1->pairs[0].ptr, &node0->pairs[npair + 1].ptr,
           (node0->npair - npair) * sizeof(typename Node::Pair) - sizeof(off_t));
    node1->npair += node0->npair - npair;
    *key = node0->pairs[npair].key;
  } else {
    // we want to move some pairs from the later (in the head) to the
    // former , which is also painful
    node0->pairs[node0->npair].key = *key;
    memcpy(&node0->pairs[node0->npair + 1].ptr,
           &node1->pairs[0].ptr,
           (npair - node0->npair) * sizeof(typename Node::Pair) - sizeof(off_t));
    *key = node1->pairs[npair - node0->npair - 1].key;
    memmove(&node1->pairs[0].ptr, &node1->pairs[npair - node0->npair].ptr,
            node1->npair * sizeof(typename Node::Pair) + sizeof(off_t));
    node1->npair += node0->npair - npair;
  }
  node0->npair = npair;
}


/*
  merge node0 and node1, with node their common parent, and npair
  pointer to node0, caller should dealloc node1 on theirown
*/
template<typename Key, typename T>
void
Mapod<Key, T>::merge(Mapod<Key, T>::Node *const node
                     ,Mapod<Key, T>::Node *const node0
                     ,Mapod<Key, T>::Node *const node1
                     ,const typename Mapod<Key, T>::Node::nPair npair)
{
  node0->pairs[node0->npair].key = node->pairs[npair].key;
  memcpy(&node0->pairs[node0->npair + 1].ptr,
         &node1->pairs[0].ptr,
         node1->npair * sizeof(typename Node::Pair) + sizeof(off_t));
  node0->npair += node1->npair + 1;
  deallocNode(node->pairs[npair + 1].ptr);
  --node->npair;
  memmove(&node->pairs[npair].key,
          &node->pairs[npair + 1].key,
          (node->npair - npair) * sizeof(typename Node::Pair));
}

template<typename Key, typename T>
off_t
Mapod<Key, T>::allocNode(const typename Mapod<Key, T>::Node::Flags flags
                         ,const typename Mapod<Key, T>::Node::nPair npair)
{
  off_t node_ = _node->alloc(_nodesize, _blksize);
  Node *node = (Node *)(*_node)[node_];
  node->flags = flags;
  node->npair = npair;
  return node_;
}

template<typename Key, typename T>
void
Mapod<Key, T>::deallocNode(const off_t off)
{
  _node->dealloc(off);
}

template <typename Key, typename T>
Mapod<Key, T>::Mapod(const std::string &prefix, const Mapod<Key, T>::KeyCompare *compare,
                     const DLD<Key> &key, const DLD<T> &t, const int k, const off_t blksize)
  :_compare(compare), _key(key), _t(t), _blksize(blksize)
{
  size_t nblk = (sizeof(Node) + sizeof(typename Node::Pair) * (2 * k) - 1) / blksize + 1;
  _k = (blksize * nblk - sizeof(Node)) / sizeof(typename Node::Pair) / 2;

  #ifdef DEBUG
  _k = 2;
  #endif

  _nodesize = sizeof(Node) + sizeof(typename Node::Pair) * (2 * _k);
  
  if ((_nodefd = open((prefix + ".node").c_str(), O_RDWR | O_CREAT,
                      S_IRUSR | S_IWUSR)) == -1) {
    error("open(): " << strerror(errno));
    return;
  }

  if ((_node = new MManager(_nodefd)) == nullptr) {
    error("new: error occured");
    return;
  }

  if ((_datafd = open((prefix + ".data").c_str(), O_RDWR | O_CREAT,
                      S_IRUSR | S_IWUSR)) == -1) {
    error("open(): " << strerror(errno));
    return;
  }

  if ((_data = new MManager(_datafd)) == nullptr) {
    error("new: error occured");
    return;
  }

  if (_node->size() == 0) {
    //the node file is empty, construct the tree then
    off_t header_ = _node->alloc(sizeof(Header));
    if (header_ != 0) {
      error("header_ != 0");
      return;
    }
    _header = (Header *)(*_node)[0];
    _header->magic = Header::MAGIC;
    
    off_t  node_ = allocNode(Node::FLAG_LEAF, 0);
    ((Node *)((*_node)[node_]))->pairs[0].ptr = -1;
    _header->root = node_;
  } else {
    _header = (Header *)(*_node)[0];
    if (_header->magic != Header::MAGIC) {
      error("magic != MAGIC");
      return;
    }
  }
}

template <typename Key, typename T>
Mapod<Key, T>::~Mapod()
{
  delete _node;
  close(_nodefd);
  delete _data;
  close(_datafd);
}

template <typename Key, typename T>
void Mapod<Key, T>::set(const Key &key, const T &t)
{
  (void)insert(key, t);
}

template <typename Key, typename T>
T Mapod<Key, T>::get(const Key &key)
{
  Slot slot(search(key));
  Node *node = slot.node;
  typename Node::nPair npair = slot.npair;
  off_t *rkey;
  if (npair < node->npair)
    rkey = &node->pairs[npair].key;
  else
    rkey = slot.rkey;

  if ((rkey != nullptr) && (!_compare(key, _key.load(*rkey, *_data))))
    return _t.load(node->pairs[npair].ptr, *_data);
  else
    return T{};
}

template <typename Key, typename T>
void Mapod<Key, T>::del(const Key &key)
{
  (void)remove(key);
}
