#include "mapod.hpp"
#include <iostream>
#include <fstream>
#include <map>
#include <vector>

using namespace std;

struct Stat {
  vector<long> _nnode;//number of nnode at the num
  vector<double> _clock; //nanoseconds passed
  long _ltime;//last timestamp of operation
  
  inline static long gettime() {
    timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000000000 + ts.tv_nsec;
  }
  inline void reset() {
    _ltime = gettime();
  }
  /* 
     add new record
  */
  inline void add(const long ops, const long nnode) {
    _nnode.push_back(nnode);
    long ltime_ = gettime();
    _clock.push_back((double)(ltime_ - _ltime) / ops);
    _ltime = ltime_;
  }

  /*
    export to csv file
  */
  void output(const char *path) {
    ofstream ofs(path, ios::trunc);
    int size = _nnode.size();
    for (int i = 0; i < size; ++i)
      ofs << _nnode[i] << "," << _clock[i] << endl;
  }
};

off_t dump(const long &t, MManager &mm)
{
  off_t off = mm.alloc(sizeof(long));
  *(long *)mm[off] = t;
  return off;
}

long load(const off_t off, MManager &mm)
{
  return *(long *)mm[off];
}

void destroy(const off_t off, MManager &mm)
{
  mm.dealloc(off);
}

#define prefix "cache_"

int main() {
  remove("map.node");
  remove("map.data");

  //DLD<long> dld{dump, load, destroy};
  //Mapod<long, long> dmap("map", Mapod<long, long>::compare, dld,
  //dld, 0, 2*1024);
  Mapod<long, long> dmap("map", Mapod<long, long>::compare, DLD<long>::defaultDLD, DLD<long>::defaultDLD, 0, 512);
  
  Stat istat;
  Stat sstat;
  Stat rstat;

#define nrecbit 7
#define nrec  (1 << nrecbit)
#define stepbit 16
#define step  (1 << stepbit)

  long inserted[step];
  for (long i = 1; i <= nrec; ++i) {
    cout << i << endl;
    //insert
    istat.reset();
    for (long j = 0; j < step; ++j)
      dmap.set(rand(), rand());
    istat.add(step, i << stepbit);

    //search
    sstat.reset();
    long sum = 0;
    for (long j = 0; j < step; ++j) {
      sum += dmap.get(rand());
    }
    sstat.add(step, i << stepbit);

    //insert again, just for deletion
    for (long j = 0; j < step; ++j) {
      long key = rand();
      dmap.set(key, rand());
      inserted[j] = key;
    }

    //remove
    rstat.reset();
    for (long j = 0; j < step; ++j)
            dmap.del(inserted[j]);
    //dmap.set(inserted[j], 0);
    rstat.add(step, i << stepbit);
  }

  istat.output(prefix "insert.csv");
  sstat.output(prefix "search.csv");
  rstat.output(prefix "remove.csv");
}
