#include "mapod.hpp"
#include <iostream>
using namespace std;

int main()
{
  Mapod<long, long> map("map");
  string command;
  long key, t;
  while (cin >> command >> key) {
    if (command == "set") {
      if (cin >> t)
        map.set(key, t);
      else
        cerr << "invalid value" << endl;
    } else if (command == "get") {
      cout << map.get(key) << endl;
    } else if (command == "del") {
      map.del(key);
    } else {
      cout << "Unknown command" << endl;
    }
  }
}
