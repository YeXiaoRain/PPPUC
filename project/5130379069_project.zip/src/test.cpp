#include "mapod.hpp"

#include <cmath>
#include <iostream>
#include <climits>
#include <map>
using namespace std;

off_t dump(const long &t, MManager &mm)
{
  off_t off = mm.alloc(sizeof(long));
  *(long *)mm[off] = t;
  return off;
}

long load(const off_t off, MManager &mm)
{
  return *(long *)mm[off];
}

void destroy(const off_t off, MManager &mm)
{
  mm.dealloc(off);
}

bool test(const int nodes, const int seed) {
  bool flag = false;
  cerr << "nodes = " << nodes  << " seed = " << seed << endl;
  remove("map.node");
  remove("map.data");
  DLD<long> dld{dump, load, destroy};
  //Mapod<long, long> dmap("map", Mapod<long, long>::compare, dld,
  //dld);
  Mapod<long, long> dmap("map");
  map<long , long > rmap;

  srand(seed);

  int snum = 0, dnum = 0;
  int min = INT_MAX, max = 0;

  for (int i = 0; i < nodes * nodes * nodes ; ++i) {
    double op = rand() / (double)RAND_MAX;
    long key = rand() % nodes;
        
    if (op < (sin((double)i / nodes / nodes) + 1) / 2) {
      //insert
      ++snum;
      long t = rand() % nodes;
      //      cout << "set " << key << " " << t << endl;
      dmap.set(key, t);
      rmap[key] = t;
      if (rmap.size() > max)
        max = rmap.size();
    } else {
      //      cout << "del " << key << endl;
      ++dnum;
      rmap.erase(key);
      dmap.del(key);
      if (rmap.size() < min)
        min = rmap.size();
    }
    //search
    key = rand() % nodes;
    long t0, t1;
    //cout << "get " << key << endl;
    if ((t0 = rmap[key]) != (t1 = dmap.get(key))) {
      cerr << key << " " << t0 << " " << t1 << endl;
      flag = true;
    }
    if (flag) break;
  }
  cerr << "set " << snum << " del " << dnum << endl;
  cerr << "min " << min << " max " << max << endl;
  cout << "--------" << endl;
  return flag;
}

int main(int argc, char *argv[])
{
  if (argc == 3) {
    test(atoi(argv[1]), atoi(argv[2]));
    return 0;
  }

  bool flag = false;

  for (int nodes = 2; nodes < 1000000; nodes <<= 1) {
    for (int seed = 0; seed < log(nodes); ++seed) {
      if (flag = test(nodes, seed))
        break;
    }
    if (flag) break;
  }
}
