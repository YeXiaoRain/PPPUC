#include "mapod.hpp"
#include <iostream>
#include <string>
using namespace std;

off_t dump(const string &t, MManager &mm)
{
  const off_t off = mm.alloc(t.size() + 1);
  char *ptr = (char *)mm[off];
  strcpy(ptr, t.c_str());
  return off;
}

string load(const off_t off, MManager &mm)
{
  const char *ptr = (char *)mm[off];
  return string(ptr);
}

void destroy(const off_t off, MManager &mm)
{
  mm.dealloc(off);
}

int main()
{
  //remove("map.node");
  //remove("map.data");
  DLD<string> dld{dump, load, destroy};
  Mapod<string, string> map("map", Mapod<string, string>::compare, dld, dld);
  string command;
  string key, t;
  while (cin >> command >> key) {
    if (command == "set") {
      if (cin >> t)
        map.set(key, t);
      else
        cerr << "invalid value" << endl;
    } else if (command == "get") {
      cout << map.get(key) << endl;
    } else if (command == "del") {
      map.del(key);
    } else {
      cout << "Unknown command" << endl;
    }
  }
}
