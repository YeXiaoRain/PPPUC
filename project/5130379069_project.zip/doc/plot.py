def readFromCSV(path):
    import numpy as np
    
    data = []
    import csv
    with open(path) as csvfile:
        reader = csv.reader(csvfile, delimiter=',')
        for row in reader:
            data.append(row);

    data = np.array(data, dtype=float);
    return data

import matplotlib.pyplot as plt
#plt.xkcd();

def drawFromCSV(path, loc):
    data = readFromCSV(path);
    return plt.plot(data[:,0]/1000000, data[:,1])[0];

def drawFromPrefix(prefix, loc = 0):
    suffix = ['insert', 'remove', 'search'];
    lines = []; labels = [];
    for suf in suffix:
        lines.append(drawFromCSV(prefix + "_" + suf + ".csv", loc));
        labels.append(suf + "(" + prefix + ")");
                                 
    print(lines)
    legend = plt.legend(lines, labels, loc=loc);
    plt.gca().add_artist(legend);

#drawFromPrefix("8k")
#drawFromPrefix("4k")
#drawFromPrefix("2k")
#drawFromPrefix("1k")
#drawFromPrefix("512")
#drawFromPrefix("256")
#drawFromPrefix("128")
#drawFromPrefix("lazy", loc=2)
#drawFromPrefix("default1M", loc=4);
#drawFromPrefix("512", loc=2)
#drawFromPrefix("1024", loc=8)
drawFromPrefix("cache", loc=2)



plt.xlabel('number of records(M)');
plt.ylabel('time consumed(ns)');
#plt.title('Default <long, long>');
plt.grid(True);
#plt.savefig("inline.png");
plt.show();

