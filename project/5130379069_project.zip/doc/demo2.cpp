#include "mapod.hpp"
#include <iostream>
int main()
{
  //"demomap" is the filename
  Mapod<long, long> map("demomap"); 
  map.set(123, 321);
  std::cout << "123 is mapped to "
            << map.get(123) << std::endl;
  map.del(123);
}
