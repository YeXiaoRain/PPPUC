/*
	ID: 5130309063
	Name: Yunhao Zhang

	Filename: checker.cpp
	Description:
		This file is a checker file for DBMS. It get the input
		file name from the terminal and output to checker.out

	Usage:
		./checker inputfile
*/

#include <cstdio>
#include <map>
#include <string>
using namespace std;

int N, idx;
const int MAX_KEY_LEN = 100000;
const int MAX_VAL_LEN = 100000;
char key[MAX_KEY_LEN + 1], val[MAX_VAL_LEN + 1];
map<string, string> Map;

void insert(int i){
    scanf("%s%s", key, val);
    
    if (Map.count(string(key))){
        printf("Insert: Exist!\n");
        return;
    }
    Map[string(key)] = string(val);
}

void remove(){
    scanf("%s", key);
    if (!Map.count(string(key))){
        printf("Remove: Not Exist!\n");
        return;
    }
    Map.erase(string(key));
}

void update(){
    scanf("%s%s", key, val);
    if (!Map.count(string(key))){
        printf("Update: Not Exist!\n");
        return;
    }
    Map[string(key)] = string(val);
}

void query(){
    scanf("%s", key);
    if (!Map.count(string(key))){
        printf("Query: Not Exist!\n");
        return;
    }
    printf("%s\n", Map[string(key)].c_str());
}

int main(int argc, char* argv[]){
    freopen(argv[1], "r", stdin);
    freopen("checker.out", "w", stdout);
    
    scanf("%d", &N);
    for(int i=1; i<=N; i++){
        scanf("%d", &idx);
        switch(idx){
            case 1:
                insert(i);
                break;
            case 2:
                remove();
                break;
            case 3:
                update();
                break;
            case 4:
                query();
                break;
        }
    }
    
    fclose(stdin);
    fclose(stdout);
    return 0;
}
