/*
	ID: 5130309063
	Name: Yunhao Zhang

	Filename: test.cpp
	Description:
		This file is a trace generator for DBFMS, it gets a 
		file name from the terminal and output a trace to that
		file

	Usage:
		./test tracefile
*/

#include <set>
#include <queue>
#include <string>
#include <cstdio>
#include <stack>
using namespace std;

#include <ctime>
#include <cstdlib>

const int N=1000000;
const int MAX_KEY_LEN = 20;
const int MAX_VAL_LEN = 50;

queue<string> Remove_List, Update_List;
stack<string> Query_List;
vector<char> alpha;

void init(){
    srand(time(0));
    for(char c='a'; c<='z'; c++)
        alpha.push_back(c);
    for(char c='A'; c<='Z'; c++)
        alpha.push_back(c);
    for(char c='0'; c<='9'; c++)
        alpha.push_back(c);
    alpha.push_back('_');
    alpha.push_back('-');
    alpha.push_back('+');
    alpha.push_back('-');
    alpha.push_back('*');
    alpha.push_back('/');
    
}

bool insert(){
    static char key[MAX_KEY_LEN+1], val[MAX_VAL_LEN+1];
    int klen = rand() % MAX_KEY_LEN + 1;
    int vlen = rand() % MAX_VAL_LEN + 1;
    
    for(int i=0; i<klen; i++)
        key[i] = alpha[rand() % alpha.size()];
    key[klen] = 0;
    for(int j=0; j<vlen; j++)
        val[j] = alpha[rand() % alpha.size()];
    val[vlen] = 0;
    printf("1 %s %s\n", key, val);
    Query_List.push(string(key));
    
    int tmp = rand() % 10;
    if (tmp < 4){
        if (tmp < 2)
            Remove_List.push(string(key));
        else
            Update_List.push(string(key));
    }
    return true;
}

bool remove(){
    if (Remove_List.size() == 0) return false;
    printf("2 %s\n", Remove_List.front().c_str());
    Query_List.push(Remove_List.front());
    Remove_List.pop();
    return true;
}

bool update(){
    static char val[MAX_VAL_LEN + 1];

    if (Update_List.size() == 0) return false;

    int vlen = rand() % MAX_VAL_LEN + 1;
    for(int j=0; j<vlen; j++)
        val[j] = alpha[rand() % alpha.size()];
    val[vlen] = 0;

    printf("3 %s %s\n", Update_List.front().c_str(), val);
    Query_List.push(Update_List.front());
    Update_List.pop();
    return true;
}

bool query(){
    if (Query_List.size() == 0) return false;
    printf("4 %s\n", Query_List.top().c_str());
    Query_List.pop();
    return true;
}

void gen_operation(){
    //4 2 2 5
    while(true){
        int tmp = rand() % 13;
        if (tmp < 4 && insert()) break;
        if (tmp < 6 && remove()) break;
        if (tmp < 8 && update()) break;
        if (tmp < 13 && query()) break;
    }
}

int main(int argc, char* argv[]){
    init();
    freopen(argv[1], "w", stdout);
    printf("%d\n", N);
    for(int i=0; i<N; i++){
        gen_operation();
    }

    
    fclose(stdout);
    return 0;
}
