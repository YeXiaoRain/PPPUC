/*
	ID: 5130309063
	Name: Yunhao Zhang

	Filename: BPlusTree.h
	Description:
		This file contains the implementation of a B+ Tree
		Based on "class Random_Alloc" and "class Fix_Alloc"
		to store , read and modify key/value pairs in disks

*/

#ifndef _BPLUSTREE_H_
#define _BPLUSTREE_H_

#include "Random_Alloc.h"
#include "Fix_Alloc.h"

#include <stack>
using std::stack;

#define _BTREE_BRANCH_ 4

#define _SEARCH_INSERT_ 1
#define _SEARCH_DELETE_ 2
#define _SEARCH_QUERY_ 3

class BPlusTree{
private:
	// Stucture for a node in B+ Tree
    struct node{
        int num;
        bool leaf;
        int keys[_BTREE_BRANCH_-1];
        int branch[_BTREE_BRANCH_];     // for leaves its value
    } blankNode;

public:

BPlusTree(const char *treefile, const char *datafile){
	// tree stores the B+ Tree
	// data stores the keys and values (c style strings)
    tree = new Fix_Alloc(treefile, sizeof(node));
    data = new Random_Alloc(datafile);

	// initialize blankNode for further insertion
    blankNode.num = 0;
    blankNode.leaf = true;
    memset(blankNode.keys, 0, sizeof(int) * (_BTREE_BRANCH_-1));
    memset(blankNode.branch, 0, sizeof(int) * _BTREE_BRANCH_);

	// If this is a new database, insert the root node
    if (tree->getSize() == 1)
        addNode();
}

~BPlusTree(){
    delete tree;
    delete data;
}

// binary search for a key in a B+ Tree node
int binarySearch(node* now, const char *val, int flag){
    int l=0, r=now->num;
    while(l != r){
        int mid = (l + (r-1)) >> 1;
        int tmp = data->compare(now->keys[mid], val);
        if (tmp == 0){
			// if "val" already exists, can not insert again
            if (flag == _SEARCH_INSERT_)
                return -1;
			// return mid when remove, update or query
            else return mid;
        }
        if (tmp <= 0)
            l = mid+1;
        else r = mid;
    }
}

// insert into node now, at place ptr, with (key, branch)pair
void normalInsert(node *now, int ptr, int key, int branch){
	// move the items behind ptr
    for(int i=now->num-1; i>=ptr; i--){
        now->keys[i+1] = now->keys[i];
        now->branch[i+2] = now->branch[i+1];
    }
    now->num++;
    // insertion
    now->keys[ptr] = key;
    now->branch[ptr+1] = branch;
}

// remove an entry(key, branch)pair from now at place ptr
void normalRemove(node *now, int ptr){
	// move the items behind ptr
    for(int i=ptr; i<now->num-1; i++){
        now->keys[i] = now->keys[i+1];
        now->branch[i+1] = now->branch[i+2];
    }
    now->num--;
}

// put everything into buffer when overflow in insertion
int bufkey[_BTREE_BRANCH_+1], bufbranch[_BTREE_BRANCH_+1];
void splitBuf(node *now, int ptr, int newkey, int newbranch){
	// put everything before ptr into buffer
	for(int i=0; i<ptr; i++){
        bufkey[i] = now->keys[i];
        bufbranch[i] = now->branch[i];
    }
    bufbranch[ptr] = now->branch[ptr];
    
	// put new (newkey, newbranch) into buffer
    bufkey[ptr] = newkey;
    bufbranch[ptr+1] = newbranch;
    
	// put everythin behind ptr into buffer
    for(int i=ptr; i<now->num; i++){
        bufkey[i+1] = now->keys[i];
        bufbranch[i+2] = now->branch[i+1];
    }
}

// Split a normal node(not root) when overflow
void normalSplit(node *now, int ptr, int& newkey, int& newbranch){
    int right = addNode();
    int nowkey = newkey, nowbranch = newbranch;
    node* node2 = (node*) tree->use(right);
    
	// put everything into buffer first
	splitBuf(now, ptr, nowkey, nowbranch);
    node2->leaf = now->leaf;
    now->num = node2->num = (_BTREE_BRANCH_ >> 1);
    
    // split node "now" into "now" and "right" using buffer
    for(int i=0; i<now->num; i++){
        now->keys[i] = bufkey[i];
        now->branch[i] = bufbranch[i];
    }
    now->branch[now->num] = bufbranch[now->num];
    
    for(int i=now->num; i<=_BTREE_BRANCH_; i++){
        node2->keys[i - now->num] = bufkey[i];
        node2->branch[i - now->num+1] = bufbranch[i+1];
    }
    
	// update newbranch and newkey for father node to update
    newbranch = right;
    newkey = node2->keys[0];
    tree->unuse(right);
}

// Split a root node
void rootSplit(node *now, int ptr, int newkey, int newbranch){
    treeDepth++;

	// keep root to be node with addr=1 (Fix_Alloc.h)
	int left = addNode();
    int right = addNode();

    node* node1 = (node*) tree->use(left);
    node* node2 = (node*) tree->use(right);
    
    node1->leaf = node2->leaf = now->leaf;
    node1->num = node2->num = (_BTREE_BRANCH_ >> 1);
    
	// put everything into buffer first
	splitBuf(now, ptr, newkey, newbranch);    

	// Split buffer into node1 and node2
    for(int i=0; i<node1->num; i++){
        node1->keys[i] = bufkey[i];
        node1->branch[i] = bufbranch[i];
    }
    node1->branch[node1->num] = bufbranch[node1->num];
    
    for(int i=node1->num; i<=_BTREE_BRANCH_; i++){
        node2->keys[i-node1->num] = bufkey[i];
        node2->branch[i-node1->num+1] = bufbranch[i+1];
    }
    
	// update root information
    now->num = 1;
    now->leaf = false;
    now->keys[0] = node2->keys[0];
    now->branch[0] = left;
    now->branch[1] = right;
    
    tree->unuse(left);
    tree->unuse(right);
}

// insert routine
bool insert(const char *key, const char *val){
	// dfs Stack
	stack<dfsPair> Stack;
    int ptr, newkey, newbranch, addr=0;
    node* now = (node*) tree->use(addr);

	// dfs implemented by loop
	while(1){
        ptr = binarySearch(now, key, _SEARCH_INSERT_);
        if (ptr == -1) {
			// Already exists, can not insert again
            while(Stack.size()){
                tree->unuse(Stack.top().addr);
                Stack.pop();
            }
            return false;
        }
        Stack.push(dfsPair(now, addr, ptr));
        if (now->leaf) break;
        addr = now->branch[ptr];
        now = (node*) tree->use(now->branch[ptr]);
    }

	// create new key and data in data file
    newkey = data->insert(key, strlen(key));
    newbranch = data->insert(val, strlen(val));

	// recall by Stack, deal with overflow
    while(1){
        now = Stack.top().p;
        ptr = Stack.top().ptr;
        addr = Stack.top().addr;
        Stack.pop();

        if (now->num != _BTREE_BRANCH_-1){
			// can be insert normally, insert and break
            normalInsert(now, ptr, newkey, newbranch);
            tree->unuse(addr);
            break;
        } else{
            if (!Stack.size()){
				// if Stack is empty, then now is root
                rootSplit(now, ptr, newkey, newbranch);
                tree->unuse(addr);
                break;
            } else{
				// Split normal node
                normalSplit(now, ptr, newkey, newbranch);
                tree->unuse(addr);
            }
        }
    }
    
	// free extra nodes in dfs Stack
    while(Stack.size()){
        tree->unuse(Stack.top().addr);
        Stack.pop();
    }
    return true;
}

// query routine
bool query(const char *key, char *buf){
    int ptr, addr=0;
    node* now = (node*) tree->use(addr);

	// examine if the tree is empty
	if (now->num == 0){
        tree->unuse(addr);
        return false;
    }

    while(1){
        ptr = binarySearch(now, key, _SEARCH_QUERY_);        
        if (now->leaf) {
			// dfs until meet leaf node
            if (ptr == now->num){
				// key is not in this node
                tree->unuse(addr);
                return false;
            } else{
                if (data->compare(now->keys[ptr], key))     
				// key is not now->keys[ptr]
                    return false;
				// key is now->keys[ptr]
                data->query(now->branch[ptr+1], buf);
                tree->unuse(addr);
                return true;
            }
        }
		// IMPORTANT! if now->keys[ptr] is key and now isn't leaf
		// the correct node is on the right branch
        if (ptr != now->num && data->compare(now->keys[ptr], key) == 0)
            ptr++;
        addr = now->branch[ptr];
        tree->unuse(addr);
        now = (node*) tree->use(addr);
    }
}

// update routine
bool update(const char *key, const char *val){
    int ptr, addr=0;
    node* now = (node*) tree->use(addr);

	// examine if the tree is empty
    if (now->num == 0){
        tree->unuse(addr);
        return false;
    }

    while(1){
        ptr = binarySearch(now, key, _SEARCH_QUERY_);
        if (now->leaf) {
			// dfs until meet the leaf
            if (ptr == now->num){
				// key is not in the node  (because key > now->keys[now->num-1])
                tree->unuse(addr);
                return false;
            } else{
				if (data->compare(now->keys[ptr], key))
				// key doesn't equal to now->keys[ptr]
                    return false;
				// key is now->keys[ptr]
                data->remove(now->branch[ptr+1]);
                now->branch[ptr+1] = data->insert(val, strlen(val));
                tree->unuse(addr);
                return true;
            }
        }
		// IMPORANT, see query routine for more detail
        if (ptr != now->num && data->compare(now->keys[ptr], key) == 0)
            ptr++;
        addr = now->branch[ptr];
        tree->unuse(addr);
        now = (node*) tree->use(addr);
    }
}

// remove routine
bool remove(const char *key){
    bool ret = true;
    int ptr, addr = 0;
    stack<dfsPair> Stack;
    node* now = (node*) tree->use(addr);
    
	// examine if the tree is empty
    if (now->num == 0){
        tree->unuse(addr);
        return false;
    }


	// dfs
	while(1){
        ptr = binarySearch(now, key, _SEARCH_QUERY_);
        Stack.push(dfsPair(now, addr, ptr));

        if (now->leaf) {
			// dfs until meet leaf
            if (ptr == now->num){
				// key is not in this node
                ret = false;
                goto Out;
            } else{
                if (data->compare(now->keys[ptr], key)){
					// key is not in this node
                    ret = false;
                    goto Out;
                }
				// key is in this node
                normalRemove(now, ptr);
                goto Out;
            }
        }
        if (ptr != now->num && data->compare(now->keys[ptr], key) == 0)
            ptr++;
        Stack.top().ptr = ptr;
        
        addr = now->branch[ptr];
        now = (node*) tree->use(addr);
    }
    
    
	Out:
	
	if (!ret){
		while (Stack.size()){
    		tree->unuse(Stack.top().addr);
    		Stack.pop();
	    }
	    return false;
	}

    bool tooSmall = false;
    while(Stack.size()){
        if (tooSmall){
            int left, right;
            int newidx, newkey, newbranch;

			if (Stack.top().ptr == Stack.top().p->num){
				// need to deal with the last branch
                left = Stack.top().ptr - 1;
                right = Stack.top().ptr;
                if (!borrow(1, Stack.top().p->branch[left], newidx, newkey, newbranch)){
                    // can not borrow, combine left and right
                    combine(Stack.top().p->branch[left], Stack.top().p->branch[right]);
                    normalRemove(Stack.top().p, left);
                } else{
                    // borrow one from neighbour, insert
                    Stack.top().p->keys[left] = newidx;
                    node *node2 = (node*) tree->use(Stack.top().p->branch[right]); 

                    normalInsert(node2, 0, newkey, newbranch);
                    tree->unuse(Stack.top().p->branch[right]);
                }
            } else{
				// not the last branch
                left = Stack.top().ptr;
                right = Stack.top().ptr + 1;
                if (!borrow(0, Stack.top().p->branch[right], newidx, newkey, newbranch)){
					// can not borrow, combine left and right
                    combine(Stack.top().p->branch[left], Stack.top().p->branch[right]);
                    normalRemove(Stack.top().p, left);
               } else{
					// borrow one from neighbour, insert
                    Stack.top().p->keys[left] = newidx;
                    node *node1 = (node*) tree->use(Stack.top().p->branch[left]);
                    normalInsert(node1, node1->num, newkey, newbranch);
                    tree->unuse(Stack.top().p->branch[left]);
                }
                
            }
        }
        
		// examine if root is empty now
        if (Stack.top().p->num == 0 && !Stack.top().p->leaf){
            int left = Stack.top().p->branch[0];
            node *p = (node*) tree->use(left);
            memcpy(Stack.top().p, p, sizeof(node));
            tree->unuse(left);
            tree->remove(left);
        }

        tooSmall = (Stack.top().p->num < (_BTREE_BRANCH_ >> 1));
        tree->unuse(Stack.top().addr);
        Stack.pop();
    }

	return ret;
}

// combine 2 nodes into 1, left and right are addr of the node
void combine(int left, int right){
    node* node1 = (node*) tree->use(left);
    node* node2 = (node*) tree->use(right);
    
    for(int i=0; i<node2->num; i++){
        node1->keys[i + node1->num] = node2->keys[i];
        node1->branch[i + 1 + node1->num] = node2->branch[i + 1];
    }
    node1->num = node1->num + node2->num;
    
    tree->unuse(left);
    tree->unuse(right);
	// remove the right node after combination
    tree->remove(right);
}

// borrow a key from node addr
// if flag == 1, borrow the right one. If flag == 0, borrow the left one
bool borrow(bool flag, int addr, int& newidx, int& newkey, int& newbranch){
    node *p = (node*) tree->use(addr);
	// node too small, can not borrow
	if (p->num == (_BTREE_BRANCH_ >> 1)){
        tree->unuse(addr);
        return false;
    }
    
    if (flag){
        // borrow from right
        newidx = newkey = p->keys[p->num - 1];
        newbranch = p->branch[p->num];
        normalRemove(p, p->num-1);
    } else{
        // borrow from left
        newidx = p->keys[1];
        newkey = p->keys[0];
        newbranch = p->branch[1];
        normalRemove(p, 0);
    }
    
    tree->unuse(addr);
    return true;
}

private:
    Fix_Alloc *tree;
    Random_Alloc *data;

    BPlusTree() {}

    struct dfsPair{
        node *p;
        int addr, ptr;
        dfsPair()   {}
        dfsPair(node *pp, int a, int p):
            p(pp), addr(a), ptr(p)  {}
    };

// add a Node
int addNode(){
    TotalFork++;
    return tree->insert(&blankNode);
}

};


#endif
