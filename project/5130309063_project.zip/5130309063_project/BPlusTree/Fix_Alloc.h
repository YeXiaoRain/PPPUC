/*
	ID: 5130309063
	Name: Yunhao Zhang

	Filename: Fix_Alloc.h
	Description:
		This file contains "class Fix_Alloc", which is used to
		allocate fixed length structs in disks. This class can
		also map a struct into memory by calling use() and unuse() routine
*/

#ifndef _FIX_ALLOC_H_
#define _FIX_ALLOC_H_

#include <cstdio>
#include <cstring>
#include <list>
using std::list;

#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/types.h>

#include "Global.h"


class Fix_Alloc{
public:

Fix_Alloc(const char* filename, int single=0){
    if (single > FIX_BLOCK_SIZE)
        throw string("Fix_Alloc Error: single size too large");

	// initialize variables
    header=NULL;
    memset(zeros, 0, PAGE_SIZE);
    fd = open(filename, O_RDWR | O_APPEND, S_IREAD | S_IWRITE);

	if (fd == -1){
		// need to create new file
        if (single == 0)
            throw string("Fix_Alloc Error: single size != 0");
        fd = open(filename, O_RDWR | O_APPEND | O_CREAT, S_IREAD | S_IWRITE);
        if (fd == -1)
            throw string("Fix_Alloc Error: file open failed");
        addPage();
    }
    
	// map the 1st page as header
    header = (Header*) Mmap(sizeof(Header), 0);
    if (header->total == 0){
        header->total = 1;
        header->single = single;
        blockPerPage = FIX_BLOCK_SIZE / single;
    } else{
        blockPerPage = FIX_BLOCK_SIZE / header->single;
    }
}

// insert routine
addr_t insert(void *item){    
    char *entry = (char*)item;
    Page* now_page;
    addr_t ret;
    bool cached(false);

	// check if there is an empty entry
    if (header->empty){
		// this page may be mapped already in cache
        list<Cache>::iterator it;
        for(it = cache.begin(); it != cache.end(); it++)
            if (header->empty == it->pageNum){
                now_page = (Page*)(it->start - (PAGE_SIZE - FIX_BLOCK_SIZE));
                cached = true; break;
            }
		// uncached, map it into memory
        if (!cached)
            now_page = (Page*) Mmap(sizeof(Page), header->empty*PAGE_SIZE);
    } else{
		// no empty entry in all pages, create new page
        addPage();
        now_page = (Page*) Mmap(sizeof(Page), (header->total-1) * PAGE_SIZE);
        initialPage(now_page);
        header->empty = header->total-1;
    }

	// count the address of new struct in disk
    ret = (header->empty-1) * blockPerPage + now_page->empty;
	// copy
	char *dest = ((char*)now_page->value) + header->single * (now_page->empty - 1);
    int next_empty = *(int*)dest;
    memcpy(dest, entry, header->single);

	// maintain the empty list
    now_page->empty = next_empty;
    if (now_page->empty == 0)
        header->empty = now_page->next;
    
    if (!cached)
	    unmapPage(now_page);
    return ret-1;
}

// remove routine
void remove(addr_t addr){
	// get the page number and idx number according  to addr
    page_t page = addr / blockPerPage + 1;
    int idx = addr - ((page-1) * blockPerPage) + 1;
    
	// map the page into memory and remove the entry
    Page *now_page = (Page*) Mmap(sizeof(Page), page * PAGE_SIZE);
    char *dest = ((char*)now_page->value) + header->single * (idx-1);

	// maintain the empty list
	*(int*)dest = now_page->empty;
    now_page->empty = idx;    
    if ((*(int*)dest) == 0){
        now_page->next = header->empty;
        header->empty = page;
    }
    unmapPage(now_page);
}

// use routine
void* use(addr_t addr){
	// count the page number and idx according to addr
    page_t page = addr / blockPerPage + 1;
    int idx = addr - ((page-1) * blockPerPage) + 1;

	// check if page has already mapped
    list<Cache>::iterator it;
    for(it = cache.begin(); it != cache.end(); it++)
        if (page == it->pageNum){
            it->reference++;
            return it->start + header->single * (idx - 1);
        }
    
	// need to map again
    Page *now_page = (Page*) Mmap(sizeof(Page), page * PAGE_SIZE);

	Cache newEntry;
    newEntry.pageNum = page;
    newEntry.reference = 1;
    newEntry.start = (char*)now_page->value;
    cache.push_front(newEntry);

    return (char*)now_page->value + header->single * (idx - 1);
}

// unuse routine
void unuse(addr_t addr){
    page_t page = addr / blockPerPage + 1;
    list<Cache>::iterator it;
	// clear the cache if needed
    for(it = cache.begin(); it != cache.end(); it++)
        if (page == it->pageNum){
            it->reference--;
            if (it->reference == 0) {
                unmapPage((Page *)(it->start-(PAGE_SIZE-FIX_BLOCK_SIZE)));
                cache.erase(it);
            }
            break;
        }
}

int getSize(){
    return header->total;
}

int getSingleSize(){
    return header->single;
}

private:
    int fd;
    int blockPerPage;
    char zeros[PAGE_SIZE];
    
	// structure of file header
	struct Header{
        page_t total;
        page_t empty;
        int single;
    } *header;
    
	// structure of normal Page
    struct Page{
        page_t next;
        int empty;
        char value[FIX_BLOCK_SIZE];
    };
    
	// Cache entry
    struct Cache{
        page_t pageNum;
        int reference;
        char* start;
    };
    list<Cache> cache;
    
Fix_Alloc() {}
void addPage(){
    write(fd, zeros, PAGE_SIZE);
    if (header)
        header->total++;
}

void *Mmap(size_t size, off_t offset){
    TotalMap2++;
    return mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, offset);
}

void unmapPage(Page* page){
    munmap(page, sizeof(Page));
}

// initial the empty list
void initialPage(Page* page){
    page->next = 0;
    page->empty = 1;
    for(int i=0; i<blockPerPage; i++)
        *(int*)(page->value + i * header->single) = i+2;
    *(int*)(page->value + (blockPerPage-1) * header->single) = 0;
}


};


#endif
