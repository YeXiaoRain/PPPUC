/*
	ID: 5130309063
	Name: Yunhao Zhang

	Filename: Global.h
	Description:
		This file contains all consts and macros for Random_Alloc and Fix_Alloc
*/

#ifndef _GLOBAL_H_
#define _GLOBAL_H_

#include <errno.h>
#include <string>
using std::string;

// Page Sizes
const long long PAGE_SIZE = 4096;

// page_t is the page number
typedef long long page_t;
#define RAND_BLOCK_SIZE (PAGE_SIZE - sizeof(page_t))

// addr_t is the address number for fixed size items
typedef long long addr_t;
#define FIX_PAGE_HEADER (sizeof(page_t) + sizeof(int))
#define FIX_BLOCK_SIZE (PAGE_SIZE - FIX_PAGE_HEADER)
const int CACHE_SIZE = 10;

// global variables for testing
bool GlobalMark;
int TotalMap1, TotalMap2, TotalUse, TotalCompareMap;
int TotalFork;
int treeDepth;


#endif
