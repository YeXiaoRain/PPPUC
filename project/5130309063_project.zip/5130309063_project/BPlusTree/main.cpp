/*
	ID: 5130309063
	Name: Yunhao Zhang

	Filename: main.cpp
	Description:
		This file shows an example of how to use class BPlusTree
*/

#include "BPlusTree.h"

#include <iostream>
using std::cerr;
using std::endl;

int N, idx;
char buf[100000];
char key[100000], val[100000];
BPlusTree tree("1", "2");

void insert(){
    scanf("%s%s", key, val);
    if (!tree.insert(key, val)){
        printf("Insert: Exist!\n");
        return;
    }
}

void remove(){
    scanf("%s", key);
    if (!tree.remove(key)){
        printf("Remove: Not Exist!\n");
        return;
    }
}

void update(){
    scanf("%s%s", key, val);
    if (!tree.update(key, val)){
        printf("Update: Not Exist!\n");
        return;
    }
}

void query(){
    scanf("%s", key);
    if (!tree.query(key, buf)){
        printf("Query: Not Exist!\n");
        return;
    }
    printf("%s\n", buf);
}



int main(int argc, char* argv[]){
    freopen(argv[1], "r", stdin);
    freopen("btree.out", "w", stdout);
    
    scanf("%d", &N);
    
    cerr << "N: " << N << endl;
    for(int i=1; i<=N; i++){
        scanf("%d", &idx);
        switch(idx){
            case 1:
                insert();
                break;
            case 2:
                remove();
                break;
            case 3:
                update();
                break;
            case 4:
                query();
                break;
        }
    }
    
    fclose(stdin);
    fclose(stdout);
    return 0;
}
