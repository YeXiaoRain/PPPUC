/*
	ID: 5130309063
	Name: Yunhao Zhang

	Filename: Random_Alloc.h
	Description:
		This file contains "class Random_Alloc", which can store
		c style strings on disk and remove/query by disk address. 
		The length of strings can be arbitary.
*/


#ifndef _RANDOM_ALLOC_H_
#define _RANDOM_ALLOC_H_

#include <cstdio>
#include <cstring>
#include <string>
using std::string;

#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/types.h>

#include "Global.h"

class Random_Alloc{
public:

Random_Alloc(const char* filename){
	// initialize variables
    header = NULL;
    memset(zeros, 0, PAGE_SIZE);
    fd = open(filename, O_RDWR | O_APPEND, S_IREAD | S_IWRITE);

	// need to create new file
	if (fd == -1){
        fd = open(filename, O_RDWR | O_APPEND | O_CREAT, S_IREAD | S_IWRITE);
        if (fd == -1)
            throw string("Random_Alloc Error: file open failed");
        addPage();
    }
    
    header = (Header*) Mmap(sizeof(Header), 0);
    
    if (header->total == 0)
        header->total = 1;
    
//    printf("%d %d\n", header->total, header->empty);
}

~Random_Alloc(){
    munmap(header, sizeof(Header));
    close(fd);
}

// insert routine
page_t insert(const char *value, int len){
    Page* now_block;
    page_t next_addr = 0;
    int left = 0, right = len;
    
	// store [left, right] of value into this page
    while(right > 0){
        left = (right > RAND_BLOCK_SIZE) ? (right - RAND_BLOCK_SIZE) : 0;
        if (header->empty){
			// still has empty page
            now_block = (Page*) Mmap(sizeof(Page), header->empty*PAGE_SIZE);
            page_t tmp = header->empty;
            header->empty = now_block->next;
            now_block->next = next_addr;
            next_addr = tmp;
        } else{
			// no empty page anymore
            addPage();
            now_block = (Page*) Mmap(sizeof(Page), (header->total-1)*PAGE_SIZE);
            now_block->next = next_addr;
            next_addr = header->total-1;
        }
        
		// copy string
        for(int i=left; i<right; i++)
            now_block->value[i - left] = value[i];
        
        unmapBlock(now_block);
        right -= RAND_BLOCK_SIZE;
    }
    
    return next_addr;
}

// remove routine
void remove(page_t addr){
    Page* now_block;
    page_t now_addr = addr;
    
	// recursively remove all pages
	// which comtain string begin at address addr
    while(now_addr){
        now_block = (Page*) Mmap(sizeof(Page), now_addr * PAGE_SIZE);
        memset(now_block->value, 0, RAND_BLOCK_SIZE);
		// maintain empty list
        now_addr = now_block->next;
        if (now_addr == 0)
            now_block->next = header->empty;
        unmapBlock(now_block);
    }
    
    header->empty = addr;
}

// query routine
// copy the string start at address addr to buf
void query(page_t addr, char* buf){
    Page* now_block;
    page_t now_addr = addr;
    int idx = 0;

	while(now_addr){
        now_block = (Page*) Mmap(sizeof(Page), now_addr * PAGE_SIZE);
		// copty the content in this page
		for(int i = 0; i < RAND_BLOCK_SIZE && 
                       now_block->value[i] != 0; i++)
            buf[idx++] = now_block->value[i];
        now_addr = now_block->next;
        unmapBlock(now_block);
    }
	// NULL terminated
    buf[idx++] = 0;
}

// compare a string in disk(addr) and astring in  memory(str)
int compare(page_t addr, const char *str){
    Page* now_block;
    page_t now_addr = addr;
    int idx = 0;
        
    while(now_addr){
        now_block = (Page*) Mmap(sizeof(Page), now_addr * PAGE_SIZE);
        TotalCompareMap++;   
		for(int i = 0; i < RAND_BLOCK_SIZE && 
                       now_block->value[i] != 0; i++)
            if (str[idx++] != now_block->value[i]){
				// different in some place
                char tmp1 = now_block->value[i];
                char tmp2 = str[idx-1];
                unmapBlock(now_block);
                return (tmp1 > tmp2)? 1 : -1;
            }
        now_addr = now_block->next;
        unmapBlock(now_block);    
    }
	// examine if the length is the same
    if (str[idx] == 0)
        return 0;
    else return -1;
}


private:
    
int fd;
char zeros[PAGE_SIZE];
struct Header{
    page_t total;
    page_t empty;
} *header;

struct Page{
    page_t next;
    char value[RAND_BLOCK_SIZE];
};


Random_Alloc()  {}

void addPage(){
    write(fd, zeros, PAGE_SIZE);
    if (header)
        header->total++;
}


void *Mmap(size_t size, off_t offset){
	TotalMap1++;
	return mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, offset);
}

inline void unmapBlock(Page* Block){
    munmap(Block, sizeof(Page));
}

};

#endif
