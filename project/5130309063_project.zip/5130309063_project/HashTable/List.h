/*
	ID: 5130309063
	Name: Yunhao Zhang

	Filename: List.h
	Description:
		This file contains class List which implements
		a list stucture on disk using class Fix_Alloc
		and class Random_Alloc
*/

#ifndef _LIST_H_
#define _LIST_H_

#include "Random_Alloc.h"
#include "Fix_Alloc.h"
#include "Global.h"

#define LIST_REPLACE 0
#define LIST_NREPLACE 1

class List{
public:
	// construction routine
    List(Fix_Alloc *KeySrc, Random_Alloc *ValSrc, addr_t* Head):
        keySrc(KeySrc), valSrc(ValSrc), head(Head)  {
        if (keySrc->getSingleSize() != sizeof(ListEntry))
            throw string("List Error: keysrc not for List Entry");
    }
    
	// insert routine
    bool insert(const char *key, const char* value, int flag){
        addr_t now = *head;
        while(now != -1){
            ListEntry *ent = (ListEntry*) keySrc->use(now);
			// compare key with every item in this list
            if (valSrc->compare(ent->keyRef, key)){
				// examine if key is already in disk
                if (flag == LIST_NREPLACE)
                    return false;
                valSrc->remove(ent->valRef);
                ent->valRef = valSrc->insert(value, strlen(value));
                keySrc->unuse(now);
                return true;
            }
            now = ent->next;
            keySrc->unuse(now);
        }
		// key not found
        if (flag == LIST_REPLACE)
            return false;

		// insert new pair (key, value);
		ListEntry entry;
        entry.next = *head;
        entry.keyRef = valSrc->insert(key, strlen(key));
        entry.valRef = valSrc->insert(value, strlen(value));
        
        *head = keySrc->insert(&entry);
        return true;
    }

	// remove routine
    bool remove(const char *key){
        addr_t prev = -1, now = *head;
        while(now != -1){
            ListEntry *ent = (ListEntry*) keySrc->use(now);
            if (valSrc->compare(ent->keyRef, key)){
				// found in list
                valSrc->remove(ent->keyRef);
                valSrc->remove(ent->valRef);

				// maintain empty list
                if (prev == -1){
                   *head = ent->next;
                } else{
                    ListEntry *entprev = (ListEntry*) keySrc->use(prev);
                    entprev->next = ent->next;
                    keySrc->unuse(prev);
                }
                keySrc->unuse(now);
                keySrc->remove(now);
                return true;
            }
            prev = now;
            now = ent->next;
            keySrc->unuse(now);
        }
        return false;
    }
    
	// query routine
    bool query(const char *key, char *buf){
        addr_t now = *head;
        while(now != -1){
            ListEntry *ent = (ListEntry*) keySrc->use(now);
            if (valSrc->compare(ent->keyRef, key)){
				// key found
                valSrc->query(ent->valRef, buf);
                return true;
            }
            now = ent->next;
            keySrc->unuse(now);
        }
        return false;
    }
    
private:
    Fix_Alloc *keySrc;
    Random_Alloc *valSrc;
    
    addr_t *head;
    List()  {}

};

#endif
