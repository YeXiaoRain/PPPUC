/*
	ID: 5130309063
	Name: Yunhao Zhang

	Filename: main.cpp
	Description:
		This file shows an example of how to use class HashTable
*/

#include "HashTable.h"
#include <cstdlib>

#include <iostream>
using std::cerr;
using std::endl;

char buf1[100000], buf2[100000];
HashTable table("1", "2", "3");

void insert(){
    scanf("%s%s", buf1, buf2);
    if (!table.insert(buf1, buf2))
        printf("Insert: Exist!\n");
}

void remove(){
    scanf("%s", buf1);
    if (!table.remove(buf1))
        printf("Remove: Not Exist!\n");
}

void update(){
    scanf("%s%s", buf1, buf2);
    if (!table.update(buf1, buf2))
        printf("Update: Not Exist!\n");
}

void query(){
    scanf("%s", buf1);
    if (table.query(buf1, buf2))
        printf("%s\n", buf2);
    else
        printf("Query: Not Exist!\n");
}

int main(int argc, char* argv[]){
    freopen(argv[1], "r", stdin);
    freopen("hash.out", "w", stdout);
    
    int N, opt;
    scanf("%d", &N);

	cerr << "N: " << N << endl;
    for(int i=1; i<=N; i++){
        scanf("%d", &opt);
        switch(opt){
            case 1:
                insert();
                break;
            case 2:
                remove();
                break;
            case 3:
                update();
                break;
            case 4:
                query();
                break;
        }
    }
    
    fclose(stdin);
    fclose(stdout);
    return 0;
}
