#ifndef _RANDOM_ALLOC_H_
#define _RANDOM_ALLOC_H_

#include <cstdio>
#include <cstring>
#include <string>
using std::string;

#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/types.h>

#include "Global.h"

class Random_Alloc{
public:

Random_Alloc(const char* filename){
    header = NULL;
    memset(zeros, 0, PAGE_SIZE);
    fd = open(filename, O_RDWR | O_APPEND, S_IREAD | S_IWRITE);
    if (fd == -1){
//        printf("new\n");
        fd = open(filename, O_RDWR | O_APPEND | O_CREAT, S_IREAD | S_IWRITE);
        if (fd == -1)
            throw string("Random_Alloc Error: file open failed");
        addPage();
    }
    
    header = (Header*) Mmap(sizeof(Header), 0);
    
    if (header->total == 0)
        header->total = 1;
    
//    printf("%d %d\n", header->total, header->empty);
}

~Random_Alloc(){
    munmap(header, sizeof(Header));
    close(fd);
}


page_t insert(const char *value, int len){
    Page* now_block;
    page_t next_addr = 0;
    int left = 0, right = len;    
    
    
    while(right > 0){
        left = (right > RAND_BLOCK_SIZE) ? (right - RAND_BLOCK_SIZE) : 0;
        if (header->empty){
            now_block = (Page*) Mmap(sizeof(Page), header->empty*PAGE_SIZE);
            page_t tmp = header->empty;
            header->empty = now_block->next;
            now_block->next = next_addr;
            next_addr = tmp;
        } else{
            addPage();
            now_block = (Page*) Mmap(sizeof(Page), (header->total-1)*PAGE_SIZE);
            now_block->next = next_addr;
            next_addr = header->total-1;
        }
        
        for(int i=left; i<right; i++)
            now_block->value[i - left] = value[i];
        
        unmapBlock(now_block);
        right -= RAND_BLOCK_SIZE;
    }
    
//    printf("ID: %lld, String: %s\n", next_addr, value);
    return next_addr;
}

void remove(page_t addr){
    Page* now_block;
    page_t now_addr = addr;
        
    while(now_addr){
        now_block = (Page*) Mmap(sizeof(Page), now_addr * PAGE_SIZE);
        memset(now_block->value, 0, RAND_BLOCK_SIZE);
        now_addr = now_block->next;
        if (now_addr == 0)
            now_block->next = header->empty;
        unmapBlock(now_block);
    }
    
    header->empty = addr;
}

void query(page_t addr, char* buf){
    Page* now_block;
    page_t now_addr = addr;
    int idx = 0;
    while(now_addr){
        now_block = (Page*) Mmap(sizeof(Page), now_addr * PAGE_SIZE);
        for(int i = 0; i < RAND_BLOCK_SIZE && 
                       now_block->value[i] != 0; i++)
            buf[idx++] = now_block->value[i];
        now_addr = now_block->next;
        unmapBlock(now_block);
    }
    buf[idx++] = 0;
}

bool compare(page_t addr, const char *str){
    Page* now_block;
    page_t now_addr = addr;
    int idx = 0;
        
    while(now_addr){
        now_block = (Page*) Mmap(sizeof(Page), now_addr * PAGE_SIZE);        
/*
        if (GlobalMark){
            if (errno != 2){
                printf("%d", errno);
            }
        }
*/
        for(int i = 0; i < RAND_BLOCK_SIZE && 
                       now_block->value[i] != 0; i++)
            if (str[idx++] != now_block->value[i]){
                unmapBlock(now_block);
                return false;
            }
        now_addr = now_block->next;
        unmapBlock(now_block);    
    }
//    printf("Yes %d\n", strlen(str));
    if (str[idx] == 0)
        return true;
    else return false;
}

int show_empty(){
    int cnt = 0;
    Page* now_block;
    page_t now_addr = header->empty;
    while(now_addr){
        cnt++;
//        printf("%d\n", now_addr);
        now_block = (Page*) Mmap(sizeof(Page), now_addr*PAGE_SIZE);
        now_addr = now_block->next;
        unmapBlock(now_block);
    }
    return cnt;
}

void print(page_t addr){
    Page* now_block;
    page_t now_addr = addr;
    while(now_addr){
        now_block = (Page*) Mmap(sizeof(Page), now_addr * PAGE_SIZE);
        for(int i = 0; i < RAND_BLOCK_SIZE && 
                       now_block->value[i] != 0; i++)
            printf("%c", now_block->value[i]);
        now_addr = now_block->next;
        unmapBlock(now_block);
    }
}


private:
    
int fd;
char zeros[PAGE_SIZE];
struct Header{
    page_t total;
    page_t empty;
} *header;

struct Page{
    page_t next;
    char value[RAND_BLOCK_SIZE];
};


Random_Alloc()  {}

void addPage(){
    write(fd, zeros, PAGE_SIZE);
    if (header)
        header->total++;
}

inline void unmapBlock(Page* Block){
//    msync(Block, sizeof(block), MS_SYNC);
    munmap(Block, sizeof(Page));
}

void *Mmap(size_t size, off_t offset){
    TotalMap1++;
    return mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, offset);
}

};

#endif
