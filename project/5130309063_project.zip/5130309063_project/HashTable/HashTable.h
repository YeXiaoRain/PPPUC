/*
	ID: 5130309063
	Name: Yunhao Zhang

	Filename: HashTable.h
	Description:
		This file contains class HashTable which implements a
		hash table on disk using class List in "List.h"
*/


#ifndef _HASH_TALBE_H_
#define _HASH_TABLE_H_

#include "List.h"
#define HASH_TABLE_SIZE 1000000

int hash(const char* str){
    int len = strlen(str);
    int ret = 0;

    int Pr = 17;        // 17 is a Primitive Root of Mo
    int Mo = 1000000009;
    for(int i=0; i<len; i++)
        ret = ((long long)(ret + str[i])*Pr) % Mo;
    return ret;
}

class HashTable{
public:

HashTable(const char* filename, const char* listname, const char* strname)
{
    table = new Fix_Alloc(filename, sizeof(hashEntry));
    keySrc = new Fix_Alloc(listname, sizeof(ListEntry));
    valSrc = new Random_Alloc(strname);
    
    hashEntry ent;
    ent.head = -1;
	// map all entrys in the hash table into memory
    for(int i=0; i<HASH_TABLE_SIZE; i++){
        table->insert(&ent);
        hashEntry *ent = (hashEntry*)table->use(i);
        lists[i] = new List(keySrc, valSrc, &ent->head);
    }
}

// destruction routine
~HashTable(){
	delete table;
	delete keySrc;
	delete valSrc;
	for (int i = 0; i < HASH_TABLE_SIZE; i++)
		delete lists[i];
}

// insert routine
bool insert(const char *key, const char *val){
    int h = hash(key) % HASH_TABLE_SIZE;
    return lists[h]->insert(key, val, LIST_NREPLACE);
}

// remove routine
bool remove(const char *key){
    int h = hash(key) % HASH_TABLE_SIZE;
    return lists[h]->remove(key);
}

// update routine
bool update(const char *key, const char *val){
    int h = hash(key) % HASH_TABLE_SIZE;
    return lists[h]->insert(key, val, LIST_REPLACE);    
}

// query routine
bool query(const char *str, char* buf){
    int h = hash(str) % HASH_TABLE_SIZE;
    return lists[h]->query(str, buf);
}


private:
	// structure of a hash slot
    struct hashEntry{
        addr_t head;
    };

	Random_Alloc *valSrc;
    Fix_Alloc *keySrc, *table;
    List *lists[HASH_TABLE_SIZE];

	HashTable() {}
};

#endif
