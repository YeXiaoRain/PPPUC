#include <stdio.h>
#include <stdlib.h>
#include "KQueens.h"
#include "Chessboard.h"

/*
 * You should modify this function. Before you start, make
 * sure you have a clear idea of what you are doing.
 * Good Luck!
 */

int KQueens(Chessboard *c)
{
  return -1;
}
